<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kategori_post extends Model
{
    protected $fillable = ['kategori_id', 'post_id'];
}
